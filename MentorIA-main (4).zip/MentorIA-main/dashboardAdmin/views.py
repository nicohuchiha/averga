# dashboardAdmin/views.py

from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.clickjacking import xframe_options_sameorigin
from django.views.decorators.cache import never_cache

# ⚠️ ¡ATENCIÓN! DEBES AJUSTAR LA SIGUIENTE LÍNEA A LA RUTA CORRECTA DE TU DECORADOR
# Por ejemplo, si está en una app llamada "core" en un archivo "decorators.py",
# sería: from core.decorators import role_required
from login.decorators import role_required 

from login.models import PersonaFisica, Rol
from dashboardProfesor.models import Profesor
from dashboardTutor.models import Tutor
from datetime import date
from .forms import DocenteForm, TutorForm,DiscapacidadForm
from dashboardTutor.models import TipoDiscapacidad, DiscapacidadEspecifica
from django.core.paginator import Paginator
from django.http import JsonResponse


@login_required
@role_required(allowed_roles=[1])
@never_cache
def index_view(request):
    """
    Vista principal del dashboard de administrador
    """
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return redirect('login:home')
    
    context = {
        'user': request.user,
    }
    return render(request, 'dashboardAdmin/index.html', context)


@login_required
@role_required(allowed_roles=[1])
def docentes_view(request):
    from django.core.paginator import Paginator
    from django.db.models import Q
    
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return redirect('login:home')

    lista_de_docentes = PersonaFisica.objects.filter(id_rol__pk=2).select_related("profesor")
    
    # Obtener parámetros de búsqueda y filtros
    search_query = request.GET.get('search', '').strip()
    estado_filter = request.GET.get('estado', '')
    
    # Aplicar búsqueda (nombre, apellido, DNI, email)
    if search_query:
        lista_de_docentes = lista_de_docentes.filter(
            Q(nombre__icontains=search_query) |
            Q(apellido__icontains=search_query) |
            Q(dni__icontains=search_query) |
            Q(mail__icontains=search_query)
        )
    
    # Aplicar filtro de estado
    if estado_filter == 'activo':
        lista_de_docentes = lista_de_docentes.filter(is_active=True)
    elif estado_filter == 'inactivo':
        lista_de_docentes = lista_de_docentes.filter(is_active=False)
    
    # Ordenar resultados
    lista_de_docentes = lista_de_docentes.order_by('apellido', 'nombre')
    
    # Paginación
    items_per_page = request.GET.get('per_page', '10')
    try:
        items_per_page = int(items_per_page)
        if items_per_page not in [10, 25, 50, 100]:
            items_per_page = 10
    except ValueError:
        items_per_page = 10
    
    paginator = Paginator(lista_de_docentes, items_per_page)
    page_number = request.GET.get('page', 1)
    docentes_page = paginator.get_page(page_number)
    
    context = {
        'user': request.user,
        'docentes': docentes_page,
        'search_query': search_query,
        'estado_filter': estado_filter,
        'items_per_page': items_per_page,
        'total_docentes': paginator.count,
    }
    return render(request, 'dashboardAdmin/docentes.html', context)

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def registrar_docente_view(request):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return render(request, 'dashboardAdmin/acceso_denegado.html')

    if request.method == 'POST':
        form = DocenteForm(request.POST)
        if form.is_valid():
            ID_ROL_DOCENTE = 2
            try:
                rol_docente = Rol.objects.get(pk=ID_ROL_DOCENTE)
            except Rol.DoesNotExist:
                messages.error(request, f'Error Crítico: El Rol con ID {ID_ROL_DOCENTE} no existe.')
                return HttpResponse('<script>window.parent.postMessage("operation-failed", "*");</script>')

            nuevo_docente = form.save(commit=False)
            nuevo_docente.id_rol = rol_docente
            nuevo_docente.fechaRegistro = date.today()
            nuevo_docente.is_active = True
            dni_value = form.cleaned_data.get('dni')
            
            # ✅ SOLUCIÓN: Usar .password en lugar de .contraseña
            nuevo_docente.password = str(dni_value)
            
            nuevo_docente.save()

            especialidad = form.cleaned_data.get('especialidad')
            Profesor.objects.create(
                persona=nuevo_docente,
                especialidad=especialidad
            )
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
    else:
        form = DocenteForm()

    return render(request, 'dashboardAdmin/registrar_docente.html', {'form': form})

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def modificar_docente_view(request, docente_id):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return render(request, 'dashboardAdmin/acceso_denegado.html')

    docente = get_object_or_404(PersonaFisica, pk=docente_id)

    if request.method == 'POST':
        form = DocenteForm(request.POST, instance=docente)
        if form.is_valid():
            form.save()

            nueva_especialidad = form.cleaned_data.get('especialidad')
            if hasattr(docente, 'profesor'):
                profesor_relacionado = docente.profesor
                profesor_relacionado.especialidad = nueva_especialidad
                profesor_relacionado.save()
            
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
    else:
        form = DocenteForm(instance=docente)
        if hasattr(docente, 'profesor'):
            form.fields['especialidad'].initial = docente.profesor.especialidad

    context = {
        'form': form,
        'docente': docente
    }
    return render(request, 'dashboardAdmin/modificar_docente.html', context)

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def eliminar_docente_view(request, docente_id):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return render(request, 'dashboardAdmin/acceso_denegado.html')

    docente = get_object_or_404(PersonaFisica, pk=docente_id)

    if docente.id_rol.pk != 2:
        messages.error(request, 'Solo se pueden eliminar docentes.')
        return HttpResponse('<script>window.parent.postMessage("operation-failed", "*");</script>')

    if request.method == 'POST':
        try:
            docente.delete()
            messages.success(request, 'Docente eliminado correctamente.')
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
        except Exception as e:
            messages.error(request, f'Error al eliminar el docente: {e}')
            return HttpResponse('<script>window.parent.postMessage("operation-failed", "*");</script>')

    return render(request, 'dashboardAdmin/confirmar_eliminacion_docente.html', {'docente': docente})


# Vistas para tutores

@login_required
@role_required(allowed_roles=[1])
def tutores_view(request):
    from django.db.models import Q
    
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return redirect('login:home')

    # Obtener la lista completa de tutores
    lista_de_tutores = PersonaFisica.objects.filter(id_rol__pk=3)
    
    # Obtener parámetros de búsqueda y filtros
    search_query = request.GET.get('search', '').strip()
    estado_filter = request.GET.get('estado', '')
    
    # Aplicar búsqueda (nombre, apellido, DNI, email)
    if search_query:
        lista_de_tutores = lista_de_tutores.filter(
            Q(nombre__icontains=search_query) |
            Q(apellido__icontains=search_query) |
            Q(dni__icontains=search_query) |
            Q(mail__icontains=search_query)
        )
    
    # Aplicar filtro de estado
    if estado_filter == 'activo':
        lista_de_tutores = lista_de_tutores.filter(is_active=True)
    elif estado_filter == 'inactivo':
        lista_de_tutores = lista_de_tutores.filter(is_active=False)
    
    # Ordenar resultados
    lista_de_tutores = lista_de_tutores.order_by('apellido', 'nombre')
    
    # Paginación
    items_per_page = request.GET.get('per_page', '10')
    try:
        items_per_page = int(items_per_page)
        if items_per_page not in [10, 25, 50, 100]:
            items_per_page = 10
    except ValueError:
        items_per_page = 10
    
    paginator = Paginator(lista_de_tutores, items_per_page)
    page_number = request.GET.get('page', 1)
    tutores_page = paginator.get_page(page_number)

    context = {
        'user': request.user,
        'tutores': tutores_page,
        'search_query': search_query,
        'estado_filter': estado_filter,
        'items_per_page': items_per_page,
        'total_tutores': paginator.count,
    }
    return render(request, 'dashboardAdmin/tutores.html', context)

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def registrar_tutor_view(request):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return render(request, 'dashboardAdmin/acceso_denegado.html')

    if request.method == 'POST':
        form = TutorForm(request.POST)
        if form.is_valid():
            ID_ROL_TUTOR = 3
            try:
                rol_tutor = Rol.objects.get(pk=ID_ROL_TUTOR)
            except Rol.DoesNotExist:
                messages.error(request, f'Error Crítico: El Rol con ID {ID_ROL_TUTOR} no existe.')
                return HttpResponse('<script>window.parent.postMessage("operation-failed", "*");</script>')

            nuevo_tutor = form.save(commit=False)
            nuevo_tutor.id_rol = rol_tutor
            nuevo_tutor.fechaRegistro = date.today()
            nuevo_tutor.is_active = True
            dni_value = form.cleaned_data.get('dni')
            
            # ✅ SOLUCIÓN: Usar .password en lugar de .contraseña
            nuevo_tutor.password = str(dni_value)
            
            nuevo_tutor.save()

            Tutor.objects.create(
                persona=nuevo_tutor
            )
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
    else:
        form = TutorForm()

    return render(request, 'dashboardAdmin/registrar_tutor.html', {'form': form})

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def modificar_tutor_view(request, tutor_id):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return render(request, 'dashboardAdmin/acceso_denegado.html')

    tutor = get_object_or_404(PersonaFisica, pk=tutor_id)

    if request.method == 'POST':
        form = TutorForm(request.POST, instance=tutor)
        if form.is_valid():
            form.save()
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
    else:
        form = TutorForm(instance=tutor)

    context = {
        'form': form,
        'tutor': tutor
    }
    return render(request, 'dashboardAdmin/modificar_tutor.html', context)

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def eliminar_tutor_view(request, tutor_id):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return render(request, 'dashboardAdmin/acceso_denegado.html')

    tutor = get_object_or_404(PersonaFisica, pk=tutor_id)

    if tutor.id_rol.pk != 3:
        messages.error(request, 'Solo se pueden eliminar tutores.')
        return HttpResponse('<script>window.parent.postMessage("operation-failed", "*");</script>')

    if request.method == 'POST':
        try:
            tutor.delete()
            messages.success(request, 'Tutor eliminado correctamente.')
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
        except Exception as e:
            messages.error(request, f'Error al eliminar el tutor: {e}')
            return HttpResponse('<script>window.parent.postMessage("operation-failed", "*");</script>')

    return render(request, 'dashboardAdmin/confirmar_eliminacion_tutor.html', {'tutor': tutor})

@login_required
@role_required(allowed_roles=[1])
def gestion_discapacidades_view(request):
    """
    Vista para LISTAR las discapacidades agrupadas por tipo en un acordeón.
    """
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 1:
        return redirect('login:home')

    # ✅ OBTENEMOS LOS TIPOS CON SUS DISCAPACIDADES PRE-CARGADAS
    tipos_con_discapacidades = TipoDiscapacidad.objects.prefetch_related('especificas').order_by('nombre')
    
    context = {
        'user': request.user,
        'tipos_con_discapacidades': tipos_con_discapacidades
    }
    return render(request, 'dashboardAdmin/gestion_discapacidades.html', context)



# dashboardAdmin/views.py

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def registrar_discapacidad_view(request):
    """
    Gestiona el registro de una nueva discapacidad.
    """
    if request.method == 'POST':
        form = DiscapacidadForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
        else:
            # ✅ SI HAY ERRORES, LOS AÑADIMOS A LOS MENSAJES
            for error in form.non_field_errors():
                messages.error(request, error)
            for field in form:
                for error in field.errors:
                    messages.error(request, f"{field.label}: {error}")
    else:
        form = DiscapacidadForm()

    # Ahora, siempre renderizamos el template, ya sea con un form vacío o con uno que contiene errores.
    return render(request, 'dashboardAdmin/registrar_discapacidad.html', {'form': form})


@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def modificar_discapacidad_view(request, discapacidad_id):
    """
    Gestiona la modificación de una discapacidad existente.
    """
    discapacidad = get_object_or_404(DiscapacidadEspecifica, pk=discapacidad_id)
    if request.method == 'POST':
        form = DiscapacidadForm(request.POST, instance=discapacidad)
        if form.is_valid():
            form.save()
            return HttpResponse('<script>window.parent.postMessage("operation-successful", "*");</script>')
        else:
            # ✅ SI HAY ERRORES, LOS AÑADIMOS A LOS MENSAJES
            for error in form.non_field_errors():
                messages.error(request, error)
            for field in form:
                for error in field.errors:
                    messages.error(request, f"{field.label}: {error}")
    else:
        form = DiscapacidadForm(instance=discapacidad)

    context = {
        'form': form,
        'discapacidad': discapacidad
    }
    return render(request, 'dashboardAdmin/modificar_discapacidad.html', context)

@login_required
@role_required(allowed_roles=[1])
@xframe_options_sameorigin
def eliminar_discapacidad_view(request, discapacidad_id):
    """
    Gestiona la eliminación o desactivación de una discapacidad.
    - Si tiene alumnos asociados, la desactiva (baja lógica).
    - Si no tiene alumnos, la elimina permanentemente (baja física).
    """
    if request.method == 'POST':
        discapacidad = get_object_or_404(DiscapacidadEspecifica, pk=discapacidad_id)
        try:
            # Comprobamos si hay estudiantes asociados a esta discapacidad
            if discapacidad.estudiante_set.exists():
                # Baja lógica: solo la desactivamos
                discapacidad.is_active = False
                discapacidad.save()
                message = 'Discapacidad desactivada (tenía alumnos asociados).'
            else:
                # Baja física: la eliminamos por completo
                discapacidad.delete()
                message = 'Discapacidad eliminada permanentemente.'
            
            return JsonResponse({'status': 'success', 'message': message})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': f'Error: {str(e)}'}, status=500)
    
    return JsonResponse({'status': 'error', 'message': 'Método no permitido.'}, status=405)


@login_required
@xframe_options_sameorigin
@role_required(allowed_roles=[1])
def reactivar_discapacidad_view(request, discapacidad_id):
    """
    Reactiva una discapacidad que tenía una baja lógica.
    """
    if request.method == 'POST':
        discapacidad = get_object_or_404(DiscapacidadEspecifica, pk=discapacidad_id)
        try:
            discapacidad.is_active = True
            discapacidad.save()
            return JsonResponse({'status': 'success', 'message': 'Discapacidad reactivada correctamente.'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': f'Error al reactivar: {str(e)}'}, status=500)
            
    return JsonResponse({'status': 'error', 'message': 'Método no permitido.'}, status=405)