from django.db import models
from login.models import PersonaFisica

# Create your models here.
class Profesor(models.Model):
    persona = models.OneToOneField(PersonaFisica, on_delete=models.CASCADE, primary_key=True)
    especialidad = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"{self.persona.nombre} {self.persona.apellido}"