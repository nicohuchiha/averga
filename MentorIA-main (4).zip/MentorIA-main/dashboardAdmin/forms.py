# dashboardAdmin/forms.py
import re
from django import forms
from django.core.validators import RegexValidator
from login.models import PersonaFisica
from dashboardTutor.models import DiscapacidadEspecifica, TipoDiscapacidad

VALIDATOR_LETRAS = RegexValidator(
    r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$',
    'Este campo solo debe contener letras y espacios.'
)


class DocenteForm(forms.ModelForm):

    especialidad = forms.CharField(
        max_length=25,
        required=False,
        validators=[VALIDATOR_LETRAS],
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ej: Matemática, Historia...',
            'oninput' : "this.value=this.value.replace(/[^A-Za-záéíóúÁÉÍÓÚñÑ\s]/g,'')"
        }),
        label="Especialidad"
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            self.fields['dni'].widget.attrs['readonly'] = True
            self.fields['dni'].help_text = 'El DNI no se puede modificar.'

    class Meta:
        model = PersonaFisica
        fields = ['nombre', 'apellido', 'dni', 'mail', 'numCel', 'is_active']
        labels = {
            'numCel': 'Número de Teléfono',
            'is_active': 'Estado',
            'dni': 'DNI',
        }
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Juan','pattern': '[A-Za-záéíóúÁÉÍÓÚñÑ\s]*','oninput': "this.value=this.value.replace(/[^A-Za-záéíóúÁÉÍÓÚñÑ\s]/g,'')"}),
            'apellido': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Pérez','pattern': '[A-Za-záéíóúÁÉÍÓÚñÑ\s]*','oninput': "this.value=this.value.replace(/[^A-Za-záéíóúÁÉÍÓÚñÑ\s]/g,'')"}),
            'dni': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Sin puntos ni espacios', 'inputmode': 'numeric', 'pattern': '[0-9]*'}),
            'mail': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'ejemplo@dominio.com'}),
            'numCel': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: 1122334455', 'inputmode': 'numeric', 'pattern': '[0-9]*','maxlength': '15'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input', 'role': 'switch'}),
        }
        error_messages = {
            'nombre': {'required': 'Este campo es obligatorio.'},
            'apellido': {'required': 'Este campo es obligatorio.'},
            'dni': {'required': 'Este campo es obligatorio.', 'unique': 'Ya existe una persona con este DNI.'},
            'mail': {'required': 'Este campo es obligatorio.', 'invalid': 'Ingrese un correo electrónico válido.'},
            'numCel': {'required': 'Este campo es obligatorio.'},
        }

    def clean_dni(self):
        dni = self.cleaned_data.get('dni')
        if dni:
            if not str(dni).isdigit():
                raise forms.ValidationError("El DNI solo puede contener números.")
            if not self.instance.pk and len(str(dni)) != 8:
                raise forms.ValidationError("El DNI debe tener exactamente 8 dígitos.")
            if self.instance.pk and  str(dni) != str(self.instance.dni):
                raise forms.ValidationError("No se puede modificar el DNI.")
        return dni

    def clean_numCel(self):
        numCel = self.cleaned_data.get('numCel')
        if numCel:
            if not str(numCel).isdigit():
                raise forms.ValidationError("El número de teléfono solo puede contener números.")
        return numCel

    def clean_mail(self):
        mail = self.cleaned_data.get('mail')
        if mail:
            # Validación básica de formato de email
            email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            if not re.match(email_regex, mail):
                raise forms.ValidationError("Ingrese un correo electrónico válido.")
        return mail


class TutorForm(forms.ModelForm):

    nombre = forms.CharField(
        max_length=20,
        validators=[VALIDATOR_LETRAS], 
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Juan','oninput':"this.value=this.value.replace(/[^A-Za-záéíóúÁÉÍÓÚñÑ\s]/g,'')"})
    )
    
   
    apellido = forms.CharField(
        max_length=25,
        validators=[VALIDATOR_LETRAS],
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Pérez','oninput' : "this.value=this.value.replace(/[^A-Za-záéíóúÁÉÍÓÚñÑ\s]/g,'')"})
    )
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            self.fields['dni'].widget.attrs['readonly'] = True
            self.fields['dni'].help_text = 'El DNI no se puede modificar.'

    class Meta:
        model = PersonaFisica
        fields = ['nombre', 'apellido', 'dni', 'mail', 'numCel', 'is_active']
        labels = {
            'numCel': 'Número de Teléfono',
            'is_active': 'Estado',
            'dni': 'DNI',
        }
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Juan'}),
            'apellido': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Pérez'}),
            'dni': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Sin puntos ni espacios', 'inputmode': 'numeric', 'pattern': '[0-9]*'}),
            'mail': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'ejemplo@dominio.com'}),
            'numCel': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: 1122334455', 'inputmode': 'numeric', 'pattern': '[0-9]*', 'maxlength': '15'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input', 'role': 'switch'}),
        }
        error_messages = {
            'nombre': {'required': 'Este campo es obligatorio.'},
            'apellido': {'required': 'Este campo es obligatorio.'},
            'dni': {'required': 'Este campo es obligatorio.', 'unique': 'Ya existe una persona física con este DNI.'},
            'mail': {'required': 'Este campo es obligatorio.', 'invalid': 'Ingrese un correo electrónico válido.'},
            'numCel': {'required': 'Este campo es obligatorio.'},
        }

    def clean_dni(self):
        dni = self.cleaned_data.get('dni')
        if dni:
            if not str(dni).isdigit():
                raise forms.ValidationError("El DNI solo puede contener números.")
            if not self.instance.pk and len(str(dni)) != 8:
                raise forms.ValidationError("El DNI debe tener exactamente 8 dígitos.")
            if self.instance.pk and str(dni) != str(self.instance.dni):
                raise forms.ValidationError("No se puede modificar el DNI existente.")
        return dni

    def clean_numCel(self):
        numCel = self.cleaned_data.get('numCel')
        if numCel:
            if not str(numCel).isdigit():
                raise forms.ValidationError("El número de teléfono solo puede contener números.")
        return numCel

    def clean_mail(self):
        mail = self.cleaned_data.get('mail')
        if mail:
            # Validación básica de formato de email
            email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            if not re.match(email_regex, mail):
                raise forms.ValidationError("Ingrese un correo electrónico válido.")
        return mail



class DiscapacidadForm(forms.ModelForm):
    tipo = forms.ModelChoiceField(
        queryset=TipoDiscapacidad.objects.all(),
        empty_label="-- Seleccionar tipo --",
        label="Tipo de Discapacidad",
        widget=forms.Select(attrs={'class': 'form-select'}),
        error_messages={'required': 'Este campo es obligatorio.'}
    )

    class Meta:
        model = DiscapacidadEspecifica
        fields = ['nombre', 'tipo']
        widgets = {
            'nombre': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: Dislexia'
            }),
        }
        labels = {
            'nombre': 'Nombre de la Discapacidad Específica',
        }
        error_messages = {
            'nombre': {'required': 'Este campo es obligatorio.'},
        }

    def clean(self):
        """
        Este método ahora comprueba si ya existe una discapacidad con el
        mismo nombre, sin importar el tipo.
        """
        cleaned_data = super().clean()
        nombre = cleaned_data.get("nombre")

        if nombre:
            # ✅ CAMBIO CLAVE: Buscamos si ya existe una con el mismo nombre,
            # sin importar el tipo al que pertenezca.
            queryset = DiscapacidadEspecifica.objects.filter(nombre__iexact=nombre)
            
            # Si estamos editando, excluimos el objeto actual de la búsqueda.
            if self.instance.pk:
                queryset = queryset.exclude(pk=self.instance.pk)
            
            if queryset.exists():
                # ✅ Lanzamos un nuevo error de validación más general.
                raise forms.ValidationError(
                    "Ya existe una discapacidad con este nombre."
                )
        
        return cleaned_data