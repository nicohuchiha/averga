# dashboardAdmin/urls.py

from django.urls import path
from . import views

app_name = 'dashboard_admin'

urlpatterns = [
    path('', views.index_view, name='index'),

    # Rutas para Docentes
    path('docentes/', views.docentes_view, name='docentes'),
    path('docentes/registrar/', views.registrar_docente_view, name='registrar_docente'),
    path('docentes/modificar/<int:docente_id>/', views.modificar_docente_view, name='modificar_docente'),
    path('docentes/eliminar/<int:docente_id>/', views.eliminar_docente_view, name='eliminar_docente'),

    # Rutas para Tutores
    path('tutores/', views.tutores_view, name='tutores'),
    path('tutores/registrar/', views.registrar_tutor_view, name='registrar_tutor'),
    path('tutores/modificar/<int:tutor_id>/', views.modificar_tutor_view, name='modificar_tutor'),
    path('tutores/eliminar/<int:tutor_id>/', views.eliminar_tutor_view, name='eliminar_tutor'),
    
    # Rutas para Discapacidades
    path('discapacidades/', views.gestion_discapacidades_view, name='gestion_discapacidades'),
    path('discapacidades/registrar/', views.registrar_discapacidad_view, name='registrar_discapacidad'),
    path('discapacidades/modificar/<int:discapacidad_id>/', views.modificar_discapacidad_view, name='modificar_discapacidad'),
    path('discapacidades/eliminar/<int:discapacidad_id>/', views.eliminar_discapacidad_view, name='eliminar_discapacidad'),
    path('discapacidades/reactivar/<int:discapacidad_id>/', views.reactivar_discapacidad_view, name='reactivar_discapacidad'),


]