from django.apps import AppConfig


class DashboardalumnoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dashboardAlumno'
