# dashboardAlumno/views.py

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import login_required
from login.decorators import role_required, never_cache # 

@login_required
@role_required(allowed_roles=[4])
@never_cache
def index_view(request):
    # Lógica de seguridad: solo los alumnos (rol pk=4) pueden ver esto.
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 4:
        return redirect('login:home')
    
    context = {'user': request.user}
    return render(request, 'dashboardAlumno/index.html', context)