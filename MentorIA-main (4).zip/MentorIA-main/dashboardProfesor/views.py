from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
import json
import os

from .models import Materia, Curso, ProfesorPreferencias
from dashboardAdmin.models import Profesor
from dashboardTutor.models import Estudiante
from login.decorators import role_required, never_cache

# Importar OpenAI
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

# Importar Google Gemini
try:
    import google.generativeai as genai
except ImportError:
    genai = None

@login_required
@role_required(allowed_roles=[2])
@never_cache
def index_view(request):
    """
    Dashboard principal del profesor.
    """
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 2:
        return redirect('login:login')

    try:
        profesor = Profesor.objects.get(persona=request.user)
        # Usamos el 'related_name' que definimos en el modelo Materia
        materias_asignadas = profesor.materias.all()
    except Profesor.DoesNotExist:
        profesor = None
        materias_asignadas = []
        messages.warning(request, 'Tu usuario no tiene un perfil de profesor configurado.')

    context = {
        'user': request.user,
        'materias_asignadas': materias_asignadas,
        'active_page': 'dashboard',
    }
    return render(request, 'dashboardProfesor/index.html', context)


@login_required
@role_required(allowed_roles=[2])
def asignar_materia_view(request):
    """Vista para asignar materias al profesor."""
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 2:
        return redirect('login:login')

    try:
        profesor = Profesor.objects.get(persona=request.user)

        # 1. Obtenemos los IDs de las materias que el profesor YA tiene.
        materias_ya_asignadas_ids = profesor.materias.values_list('id', flat=True)

        # 2. Buscamos todas las materias, pero EXCLUIMOS las que ya tiene.
        materias_para_asignar = Materia.objects.exclude(id__in=materias_ya_asignadas_ids)
        
        # 3. Obtenemos los años para el filtro (sin cambios)
        anos_unicos = Curso.objects.order_by('ano').values_list('ano', flat=True).distinct()

    except Profesor.DoesNotExist:
        messages.error(request, 'Tu usuario no tiene un perfil de profesor asociado.')
        return redirect('dashboardProfesor:index')

    context = {
        'anos': anos_unicos,
        # 4. Le pasamos al HTML solo la lista de materias filtradas.
        'materias': materias_para_asignar,
        'active_page': 'asignar_materia',
    }
    
    return render(request, 'dashboardProfesor/asignar_materia.html', context)


@login_required
@role_required(allowed_roles=[2])
def guardar_materias_view(request):
    """Vista para guardar las materias seleccionadas."""
    if request.method == 'POST':
        try:
            # Obtenemos el perfil del profesor a partir del usuario logueado
            profesor = Profesor.objects.get(persona=request.user)
            
            # Obtenemos la lista de IDs de los checkboxes marcados
            materias_ids = request.POST.getlist('materias_seleccionadas')

            if not materias_ids:
                messages.error(request, 'No seleccionaste ninguna materia.')
                return redirect('dashboardProfesor:asignar_materia')

            # Iteramos sobre los IDs y creamos la relación
            for materia_id in materias_ids:
                materia = Materia.objects.get(id=materia_id)
                # Usamos .add() en el 'related_name' para crear la asignación.
                # Esto funciona porque en Materia definimos related_name='materias'
                profesor.materias.add(materia)
            
            messages.success(request, f'¡Se han asignado {len(materias_ids)} materias correctamente!')
            return redirect('dashboardProfesor:asignar_materia')

        except Profesor.DoesNotExist:
            messages.error(request, 'Error: Tu usuario no tiene un perfil de profesor asociado.')
            return redirect('dashboardProfesor:index')
        except Exception as e:
            messages.error(request, f'Ocurrió un error inesperado: {e}')
            return redirect('dashboardProfesor:asignar_materia')

    return redirect('dashboardProfesor:index')
@login_required
@role_required(allowed_roles=[2])
def mis_materias_view(request):
    """
    Muestra al docente la lista de materias que tiene actualmente asignadas.
    """
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 2:
        return redirect('login:login')

    try:
        # Obtenemos el perfil del profesor a partir del usuario logueado
        profesor = Profesor.objects.get(persona=request.user)
        # Usamos el 'related_name' definido en el modelo para obtener sus materias
        materias_asignadas = profesor.materias.all().order_by('curso__ano', 'titulo')
    except Profesor.DoesNotExist:
        messages.error(request, 'Error: Tu usuario no tiene un perfil de profesor asociado.')
        return redirect('dashboardProfesor:index')

    context = {
        'mis_materias': materias_asignadas,
        'active_page': 'mis_materias', # Para el menú lateral
    }
    return render(request, 'dashboardProfesor/mis_materias.html', context)


@login_required
@role_required(allowed_roles=[2])
def desasignar_materia_view(request, materia_id):
    """
    Procesa la petición para que un docente deje de enseñar una materia.
    """
    if request.method == 'POST':
        try:
            profesor = Profesor.objects.get(persona=request.user)
            materia = Materia.objects.get(id=materia_id)

            # Usamos .remove() para eliminar la relación en la tabla intermedia.
            # Django se encarga de todo automáticamente.
            profesor.materias.remove(materia)

            messages.success(request, f'Has dejado de enseñar la materia "{materia.titulo}".')

        except Profesor.DoesNotExist:
            messages.error(request, 'Error: Tu perfil de profesor no fue encontrado.')
        except Materia.DoesNotExist:
            messages.error(request, 'Error: La materia que intentas desasignar no existe.')
        except Exception as e:
            messages.error(request, f'Ocurrió un error inesperado: {e}')
    
    # Redirigimos siempre a la lista de materias.
    return redirect('dashboardProfesor:mis_materias')


@login_required
@role_required(allowed_roles=[2])
@ensure_csrf_cookie
def chat_alumnos_view(request):
    """
    Vista para mostrar la pantalla de chat con alumnos.
    Permite seleccionar un alumno de las materias asignadas al profesor.
    """
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 2:
        return redirect('login:login')

    try:
        profesor = Profesor.objects.get(persona=request.user)
        
        # Obtener o crear preferencias del profesor
        preferencias, created = ProfesorPreferencias.objects.get_or_create(
            profesor=profesor,
            defaults={'ai_provider': os.environ.get('DEFAULT_AI_PROVIDER', 'gemini')}
        )
        
        # Obtener todas las materias del profesor
        materias_profesor = profesor.materias.all()
        
        # Obtener los cursos de esas materias
        cursos_ids = materias_profesor.values_list('curso_id', flat=True).distinct()
        
        # Obtener estudiantes por dos criterios:
        # 1. Estudiantes que tienen materias específicas del profesor
        # 2. Estudiantes que están en los cursos donde el profesor da clases
        # 3. Solo estudiantes activos (no dados de baja)
        from django.db.models import Q
        estudiantes = Estudiante.objects.filter(
            Q(materias__in=materias_profesor) | Q(curso_id__in=cursos_ids)
        ).filter(
            persona__is_active=True
        ).distinct().select_related('persona', 'curso').prefetch_related('discapacidades', 'tutores')
        
    except Profesor.DoesNotExist:
        messages.error(request, 'Error: Tu usuario no tiene un perfil de profesor asociado.')
        return redirect('dashboardProfesor:index')

    context = {
        'estudiantes': estudiantes,
        'active_page': 'chat_alumnos',
        'ai_provider': preferencias.ai_provider,
        'ai_providers': ProfesorPreferencias.AI_PROVIDERS,
    }
    return render(request, 'dashboardProfesor/chat_alumnos.html', context)


@csrf_exempt
@login_required
@role_required(allowed_roles=[2])
def chat_api_view(request):
    """
    API endpoint para comunicarse con OpenAI.
    Recibe el ID del estudiante y el mensaje del usuario.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Método no permitido'}, status=405)
    
    if not OpenAI:
        return JsonResponse({'error': 'OpenAI no está instalado. Ejecuta: pip install openai'}, status=500)
    
    try:
        data = json.loads(request.body)
        estudiante_id = data.get('estudiante_id')
        mensaje_usuario = data.get('mensaje')
        historial = data.get('historial', [])
        
        if not estudiante_id or not mensaje_usuario:
            return JsonResponse({'error': 'Faltan parámetros requeridos'}, status=400)
        
        # Validación de longitud del mensaje en servidor (robustez)
        if len(mensaje_usuario) > 500:
            return JsonResponse({'error': 'El mensaje excede el tamaño máximo permitido (500 caracteres).'}, status=400)
        
        # Obtener información del estudiante (solo si está activo)
        estudiante = Estudiante.objects.select_related('persona', 'curso').prefetch_related(
            'discapacidades__tipo', 'tutores__persona', 'materias'
        ).filter(persona__is_active=True).get(pk=estudiante_id)
        
        # Verificar que el profesor tenga acceso a este estudiante
        profesor = Profesor.objects.get(persona=request.user)
        materias_profesor = profesor.materias.all()
        materias_estudiante = estudiante.materias.all()
        
        # Obtener los cursos de las materias del profesor
        cursos_ids = list(materias_profesor.values_list('curso_id', flat=True).distinct())
        
        # Verificar acceso por dos criterios:
        # 1. El estudiante tiene materias específicas del profesor
        # 2. El estudiante está en un curso donde el profesor da clases
        tiene_materias_comunes = materias_profesor.filter(id__in=materias_estudiante.values_list('id', flat=True)).exists()
        esta_en_curso_profesor = estudiante.curso_id in cursos_ids if estudiante.curso_id else False
        
        if not (tiene_materias_comunes or esta_en_curso_profesor):
            return JsonResponse({'error': 'No tienes acceso a este estudiante'}, status=403)
        
        # Construir el prompt con información del estudiante
        discapacidades_str = ", ".join([
            f"{d.tipo.nombre} - {d.nombre}" for d in estudiante.discapacidades.all()
        ])
        
        tutores_str = ", ".join([
            f"{t.persona.nombre} {t.persona.apellido}" for t in estudiante.tutores.all()
        ])
        
        materias_str = ", ".join([m.titulo for m in materias_estudiante])
        
        curso_str = f"{estudiante.curso.titulo} (Año {estudiante.curso.ano})" if estudiante.curso else "No asignado"
        
        system_prompt = f"""Eres un asistente educativo especializado en ayudar a profesores a comprender mejor a sus estudiantes y brindar apoyo personalizado.

Información del estudiante:
- Nombre: {estudiante.persona.nombre} {estudiante.persona.apellido}
- DNI: {estudiante.persona.dni}
- Email: {estudiante.persona.mail or 'No registrado'}
- Teléfono: {estudiante.persona.numCel or 'No registrado'}
- Curso: {curso_str}
- Materias: {materias_str or 'Ninguna asignada'}
- Discapacidades: {discapacidades_str or 'Ninguna registrada'}
- Tutores: {tutores_str or 'Ninguno asignado'}
- Descripción adicional: {estudiante.descripcion_adicional or 'No hay descripción adicional'}

Tu rol es:
1. Proporcionar estrategias pedagógicas adaptadas a las necesidades del estudiante
2. Sugerir métodos de enseñanza inclusivos considerando sus discapacidades
3. Ofrecer consejos sobre cómo mejorar la comunicación con el estudiante y sus tutores
4. Ayudar al profesor a crear un ambiente de aprendizaje más accesible
5. Responder preguntas sobre adaptaciones curriculares y evaluaciones

Sé profesional, empático y enfócate en soluciones prácticas basadas en pedagogía inclusiva."""

        # Obtener preferencias del profesor
        preferencias, _ = ProfesorPreferencias.objects.get_or_create(
            profesor=profesor,
            defaults={'ai_provider': os.environ.get('DEFAULT_AI_PROVIDER', 'gemini')}
        )
        
        ai_provider = preferencias.ai_provider
        
        # MODO DE PRUEBA o Mock
        if ai_provider == 'mock':
            # Respuesta simulada para pruebas
            respuesta_ia = f"""Respuesta de prueba del Asistente IA

Hola, soy tu asistente educativo. Estoy aquí para ayudarte con estrategias pedagógicas para {estudiante.persona.nombre} {estudiante.persona.apellido}.

Información del estudiante:
- Curso: {curso_str}
- Discapacidades: {discapacidades_str or 'Ninguna registrada'}

Sugerencias generales:
1. Adaptar el material didáctico según las necesidades específicas
2. Mantener comunicación constante con los tutores
3. Implementar evaluaciones diferenciadas
4. Crear un ambiente inclusivo en el aula

Nota: Esta es una respuesta de prueba. Para obtener respuestas reales de IA, configura una API key válida de OpenAI con créditos disponibles.

Tu pregunta fue: "{mensaje_usuario}"
"""
        
        elif ai_provider == 'gemini':
            # Usar Google Gemini
            try:
                if not genai:
                    raise Exception("Google Generative AI no está instalado. Ejecuta: pip install google-generativeai")
                
                gemini_api_key = os.environ.get('GEMINI_API_KEY', 'AIzaSyBIUmxtk7aWI_FA3UDdA-PaKPp5SHeoNKA')
                genai.configure(api_key=gemini_api_key)
                
                # Modelos disponibles en orden de preferencia
                modelos_disponibles = [
                    'models/gemini-2.0-flash',
                    'models/gemini-2.5-flash',
                    'models/gemini-flash-latest',
                    'models/gemini-pro-latest',
                ]
                
                respuesta_ia = None
                ultimo_error = None
                
                for modelo_nombre in modelos_disponibles:
                    try:
                        model = genai.GenerativeModel(modelo_nombre)
                        
                        # Construir el prompt completo
                        full_prompt = f"{system_prompt}\n\n"
                        
                        # Agregar historial
                        for msg in historial:
                            role = "Usuario" if msg.get("role") == "user" else "Asistente"
                            full_prompt += f"{role}: {msg.get('content', '')}\n\n"
                        
                        # Agregar mensaje actual
                        full_prompt += f"Usuario: {mensaje_usuario}\n\nAsistente:"
                        
                        # Generar respuesta
                        response = model.generate_content(full_prompt)
                        respuesta_ia = response.text
                        break  # Si funciona, salir del loop
                        
                    except Exception as model_error:
                        ultimo_error = str(model_error)
                        continue
                
                if not respuesta_ia:
                    raise Exception(f"Ningún modelo de Gemini funcionó. Último error: {ultimo_error}")
                
            except Exception as gemini_error:
                respuesta_ia = f"""**Error al conectar con Google Gemini**

No se pudo obtener una respuesta de la IA.

**Error:** {str(gemini_error)}

**Tu pregunta:** "{mensaje_usuario}"

**Información del estudiante:**
- Nombre: {estudiante.persona.nombre} {estudiante.persona.apellido}
- Curso: {curso_str}
- Discapacidades: {discapacidades_str or 'Ninguna registrada'}

Por favor, verifica tu API key de Gemini o cambia a otro proveedor.
"""
        
        elif ai_provider == 'openai':
            # Usar OpenAI
            try:
                if not OpenAI:
                    raise Exception("OpenAI no está instalado. Ejecuta: pip install openai")
                
                openai_api_key = os.environ.get('OPENAI_API_KEY')
                if not openai_api_key:
                    raise Exception("API key de OpenAI no configurada")
                
                client = OpenAI(api_key=openai_api_key)
                
                # Construir mensajes para la API
                messages = [{"role": "system", "content": system_prompt}]
                
                # Agregar historial de conversación
                for msg in historial:
                    messages.append({
                        "role": msg.get("role", "user"),
                        "content": msg.get("content", "")
                    })
                
                # Agregar el mensaje actual
                messages.append({"role": "user", "content": mensaje_usuario})
                
                # Llamar a la API de OpenAI
                response = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=messages,
                    temperature=0.7,
                    max_tokens=500
                )
                
                respuesta_ia = response.choices[0].message.content
                
            except Exception as openai_error:
                respuesta_ia = f"""**Error al conectar con OpenAI**

No se pudo obtener una respuesta de la IA.

**Error:** {str(openai_error)}

**Tu pregunta:** "{mensaje_usuario}"

**Información del estudiante:**
- Nombre: {estudiante.persona.nombre} {estudiante.persona.apellido}
- Curso: {curso_str}
- Discapacidades: {discapacidades_str or 'Ninguna registrada'}

Por favor, verifica tu cuenta de OpenAI o cambia a otro proveedor.
"""
        
        else:
            respuesta_ia = "Error: Proveedor de IA no reconocido."
        
        return JsonResponse({
            'respuesta': respuesta_ia,
            'estudiante': {
                'nombre': f"{estudiante.persona.nombre} {estudiante.persona.apellido}",
                'id': estudiante.pk
            }
        })
        
    except Estudiante.DoesNotExist:
        return JsonResponse({'error': 'Estudiante no encontrado'}, status=404)
    except Profesor.DoesNotExist:
        return JsonResponse({'error': 'Perfil de profesor no encontrado'}, status=404)
    except Exception as e:
        return JsonResponse({'error': f'Error al procesar la solicitud: {str(e)}'}, status=500)


@csrf_exempt
@login_required
@role_required(allowed_roles=[2])
def cambiar_ai_provider_view(request):
    """
    Cambia el proveedor de IA del profesor.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Método no permitido'}, status=405)
    
    try:
        data = json.loads(request.body)
        provider = data.get('provider')
        
        if provider not in ['openai', 'gemini', 'mock']:
            return JsonResponse({'error': 'Proveedor no válido'}, status=400)
        
        profesor = Profesor.objects.get(persona=request.user)
        preferencias, _ = ProfesorPreferencias.objects.get_or_create(profesor=profesor)
        preferencias.ai_provider = provider
        preferencias.save()
        
        provider_names = {
            'openai': 'OpenAI (GPT-3.5)',
            'gemini': 'Google Gemini',
            'mock': 'Modo de Prueba'
        }
        
        return JsonResponse({
            'success': True,
            'provider': provider,
            'provider_name': provider_names.get(provider, provider)
        })
        
    except Profesor.DoesNotExist:
        return JsonResponse({'error': 'Perfil de profesor no encontrado'}, status=404)
    except Exception as e:
        return JsonResponse({'error': f'Error: {str(e)}'}, status=500)