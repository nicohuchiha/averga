from django.urls import path
from . import views

app_name = 'dashboard_profesor'

urlpatterns = [
    path('', views.index_view, name='index'),
    path('asignar/', views.asignar_materia_view, name='asignar_materia'),
    path('guardar-materias/', views.guardar_materias_view, name='guardar_materias'),
    path('mis-materias/', views.mis_materias_view, name='mis_materias'),
    path('mis-materias/desasignar/<int:materia_id>/', views.desasignar_materia_view, name='desasignar_materia'),
    path('chat-alumnos/', views.chat_alumnos_view, name='chat_alumnos'),
    path('chat-api/', views.chat_api_view, name='chat_api'),
    path('cambiar-ai-provider/', views.cambiar_ai_provider_view, name='cambiar_ai_provider'),
]