from django.db import models
# Necesitamos importar el modelo de usuario de tu app 'login'
# Asumo que se llama 'PersonaFisica' y está en 'login.models'
# Si el nombre o la ubicación son diferentes, deberás ajustar la importación.
from dashboardAdmin.models import Profesor


class Curso(models.Model):
    titulo = models.CharField(max_length=255)
    descripcion = models.TextField(blank=True, null=True)
    profesores = models.ManyToManyField(Profesor, related_name='cursos', blank=True)
    ano = models.IntegerField(verbose_name="Año")

    def __str__(self):
        return self.titulo

class Materia(models.Model):
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE, related_name='materias')
    titulo = models.CharField(max_length=255)
    # Este es el nuevo campo que relaciona Materia con Profesor
    profesores_asignados = models.ManyToManyField(Profesor, related_name='materias', blank=True)

    def __str__(self):
        return self.titulo


class ProfesorPreferencias(models.Model):
    """Preferencias del profesor para el chat con IA"""
    AI_PROVIDERS = [
        ('openai', 'OpenAI (GPT-3.5)'),
        ('gemini', 'Google Gemini'),
        ('mock', 'Modo de Prueba'),
    ]
    
    profesor = models.OneToOneField(Profesor, on_delete=models.CASCADE, related_name='preferencias_chat')
    ai_provider = models.CharField(max_length=20, choices=AI_PROVIDERS, default='gemini')
    
    def __str__(self):
        return f"Preferencias de {self.profesor} - {self.get_ai_provider_display()}"