# mysite/urls.py

from django.contrib import admin
from django.urls import path, include, re_path
from django.views.generic.base import RedirectView
from django.shortcuts import render
from django.conf import settings
from django.conf.urls.static import static
from django.views.static import serve

# Vistas de prueba para páginas de error (solo para testing en desarrollo)
def test_404_view(request):
    return render(request, '404.html', status=404)

def test_500_view(request):
    return render(request, '500.html', status=500)

urlpatterns = [
    # 1. Redirección de la página principal
    path('', RedirectView.as_view(pattern_name='login:login', permanent=False)),

    # 2. Rutas de las aplicaciones
    path('admin/', admin.site.urls),
    path('login/', include('login.urls')),
    
    # Dashboards
    path('dashboard/admin/', include('dashboardAdmin.urls')),
    path('dashboard/profesor/', include(('dashboardProfesor.urls', 'dashboardProfesor'), namespace='dashboardProfesor')),
    path('dashboard/tutor/', include('dashboardTutor.urls')),
    path('dashboard/alumno/', include('dashboardAlumno.urls')),
]

# Rutas para testing de páginas de error en desarrollo
if settings.DEBUG:
    urlpatterns += [
        path('test-404/', test_404_view, name='test_404'),
        path('test-500/', test_500_view, name='test_500'),
    ]
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# Servir archivos estáticos manualmente (funciona con DEBUG=True o False en desarrollo)

import os
BASE_DIR = settings.BASE_DIR
urlpatterns += [
    re_path(r'^static/login/(?P<path>.*)$', serve, {'document_root': os.path.join(BASE_DIR, 'login', 'static', 'login')}),
    re_path(r'^static/dashboardAdmin/(?P<path>.*)$', serve, {'document_root': os.path.join(BASE_DIR, 'dashboardAdmin', 'static', 'dashboardAdmin')}),
    re_path(r'^static/dashboardProfesor/(?P<path>.*)$', serve, {'document_root': os.path.join(BASE_DIR, 'dashboardProfesor', 'static', 'dashboardProfesor')}),
    re_path(r'^static/dashboardTutor/(?P<path>.*)$', serve, {'document_root': os.path.join(BASE_DIR, 'dashboardTutor', 'static', 'dashboardTutor')}),
    re_path(r'^static/dashboardAlumno/(?P<path>.*)$', serve, {'document_root': os.path.join(BASE_DIR, 'dashboardAlumno', 'static', 'dashboardAlumno')}),
]