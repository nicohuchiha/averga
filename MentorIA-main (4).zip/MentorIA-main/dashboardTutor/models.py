# dashboardTutor/models.py
from django.db import models
from login.models import PersonaFisica
from dashboardProfesor.models import Curso, Materia
class Tutor(models.Model):
    persona = models.OneToOneField(
        PersonaFisica,
        on_delete=models.CASCADE,
        primary_key=True,
        related_name='perfil_tutor'
    )
    def __str__(self):
        return f"{self.persona.nombre} {self.persona.apellido}"

# --- NUEVOS MODELOS ---

class TipoDiscapacidad(models.Model):
    nombre = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.nombre

class DiscapacidadEspecifica(models.Model):
    nombre = models.CharField(max_length=100)
    tipo = models.ForeignKey(TipoDiscapacidad, on_delete=models.CASCADE, related_name='especificas')
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.tipo.nombre} - {self.nombre}"

# --- MODELO ESTUDIANTE MODIFICADO ---

class Estudiante(models.Model):
    persona = models.OneToOneField(
        PersonaFisica,
        on_delete=models.CASCADE,
        primary_key=True,
        related_name='perfil_estudiante'
    )
    tutores = models.ManyToManyField(Tutor, blank=True)
    
    # Campo ForeignKey que apunta a la discapacidad específica seleccionada.
    # Permitimos que sea nulo por si se registra sin este dato inicialmente.
    discapacidades = models.ManyToManyField(DiscapacidadEspecifica, blank=True) 
   
    # Mantenemos el campo de descripción.
    descripcion_adicional = models.TextField(blank=True, null=True)
    curso = models.ForeignKey(Curso, on_delete=models.SET_NULL, null=True, blank=True, related_name='estudiantes')
    materias = models.ManyToManyField(Materia, blank=True, related_name='estudiantes')

    def __str__(self):
        return f"{self.persona.nombre} {self.persona.apellido}"