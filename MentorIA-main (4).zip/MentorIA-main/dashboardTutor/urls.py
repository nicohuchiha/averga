# dashboardTutor/urls.py

from django.urls import path
from . import views

# El app_name es crucial para poder usar {% url 'dashboard_tutor:...' %}
app_name = 'dashboard_tutor'

urlpatterns = [
    # Ruta para el dashboard principal (lista de alumnos)
    # URL: /dashboard/tutor/
    path('', views.index_view, name='index'),
    
    # Ruta para la página de registro de alumnos
    # URL: /dashboard/tutor/registrar/
    path('registrar/', views.registrar_alumno_view, name='registrar_alumno'),
    
    # Ruta para editar un alumno (necesita el ID de la persona)
    # URL: /dashboard/tutor/editar/1/ (por ejemplo)
    path('editar/<int:persona_id>/', views.editar_alumno_view, name='editar_alumno'),
    
    # Ruta para eliminar (dar de baja) a un alumno
    # URL: /dashboard/tutor/eliminar/1/ (por ejemplo)
    path('eliminar/<int:persona_id>/', views.eliminar_alumno_view, name='eliminar_alumno'),
    path('alumnos/', views.alumnos_view, name='alumnos'), # La página que listará a tus alumnos
    path('reactivar/<int:persona_id>/', views.reactivar_alumno_view, name='reactivar_alumno'),

    
]