# dashboardTutor/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from login.models import PersonaFisica, Rol 
from .forms import AlumnoForm
from dashboardProfesor.models import Curso 
from datetime import date
from .models import Estudiante, Tutor, TipoDiscapacidad, DiscapacidadEspecifica
from login.decorators import role_required, never_cache

@login_required
@role_required(allowed_roles=[3])
@never_cache
def index_view(request):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 3:
        return redirect('login:home')
    
    tutor = get_object_or_404(Tutor, persona=request.user)
    alumnos = tutor.estudiante_set.all()

    context = {
        'user': request.user,
        'alumnos': alumnos
    }
    return render(request, 'dashboardTutor/tutor_index.html', context)


@login_required
@role_required(allowed_roles=[3])
def registrar_alumno_view(request):
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 3:
        return redirect('login:login')

    if request.method == 'POST':
        form = AlumnoForm(request.POST)
        if form.is_valid():
            try:
                # La validación de DNI duplicado ya se hace en el formulario (forms.py)
                # pero la dejamos aquí como validación adicional de seguridad
                dni_value = form.cleaned_data.get('dni')
                
                persona = form.save(commit=False)
                rol_alumno = Rol.objects.get(pk=4)
                persona.id_rol = rol_alumno
                persona.fechaRegistro = date.today()
                persona.password = str(dni_value)
                persona.save()

                descripcion_adicional = request.POST.get('descripcion_adicional', '').strip()
                # Validar longitud máxima de descripción adicional
                if len(descripcion_adicional) > 255:
                    messages.error(request, 'La descripción adicional no puede tener más de 255 caracteres.')
                    persona.delete()
                    # Mantener los datos del formulario para que el usuario pueda corregir
                    return render(request, 'dashboardTutor/registrar_alumno.html', {
                        'form': form,
                        'tipos_discapacidad': TipoDiscapacidad.objects.all(),
                        'especificas_discapacidad': DiscapacidadEspecifica.objects.all(),
                        'cursos': Curso.objects.all(),
                        'active_page': 'registrar_alumno',
                    })
                
                curso_id = request.POST.get('curso')
                if not curso_id:
                    messages.error(request, 'Debes seleccionar un curso para el alumno.')
                    persona.delete()
                    # Mantener los datos del formulario
                    return render(request, 'dashboardTutor/registrar_alumno.html', {
                        'form': form,
                        'tipos_discapacidad': TipoDiscapacidad.objects.all(),
                        'especificas_discapacidad': DiscapacidadEspecifica.objects.all(),
                        'cursos': Curso.objects.all(),
                        'active_page': 'registrar_alumno',
                    })
                
                discapacidades_ids_str = request.POST.get('discapacidades_seleccionadas', '')
                if not discapacidades_ids_str:
                    messages.error(request, 'Debes seleccionar al menos una discapacidad para el alumno.')
                    persona.delete()
                    # Mantener los datos del formulario
                    return render(request, 'dashboardTutor/registrar_alumno.html', {
                        'form': form,
                        'tipos_discapacidad': TipoDiscapacidad.objects.all(),
                        'especificas_discapacidad': DiscapacidadEspecifica.objects.all(),
                        'cursos': Curso.objects.all(),
                        'active_page': 'registrar_alumno',
                    })
                
                estudiante = Estudiante.objects.create(
                    persona=persona,
                    descripcion_adicional=descripcion_adicional
                )
                
                estudiante.curso = Curso.objects.get(pk=curso_id)

                ids_lista = discapacidades_ids_str.split(',')
                estudiante.discapacidades.set(ids_lista)
                
                estudiante.save()
                
                try:
                    tutor_actual = Tutor.objects.get(persona=request.user)
                    estudiante.tutores.add(tutor_actual)
                except Tutor.DoesNotExist:
                    messages.error(request, 'Error: No se encontró tu perfil de tutor.')
                    persona.delete() 
                    return redirect('dashboard_tutor:index')

                messages.success(request, '¡Alumno registrado con éxito! Puedes registrar otro.')
                return redirect('dashboard_tutor:registrar_alumno')
            except Exception as e:
                messages.error(request, f'Error al registrar el alumno: {str(e)}')
                # Mantener los datos del formulario en caso de error
        else:
            # Mostrar errores del formulario de manera más clara
            for field, errors in form.errors.items():
                field_name = form.fields[field].label if field in form.fields else field
                for error in errors:
                   messages.error(request, f'{field_name.upper()}: {error}')
            # NO reinicializar el formulario - mantener los datos ingresados
            selected_curso = request.POST.get('curso', '')
            descripcion_adicional = request.POST.get('descripcion_adicional', '')
            discapacidades_seleccionadas = request.POST.get('discapacidades_seleccionadas', '')
    else:
        form = AlumnoForm()

    tipos_discapacidad = TipoDiscapacidad.objects.all()
    especificas_discapacidad = DiscapacidadEspecifica.objects.all()
    todos_los_cursos = Curso.objects.all()
    
    context = {
        'form': form,
        'tipos_discapacidad': tipos_discapacidad,
        'especificas_discapacidad': especificas_discapacidad,
        'cursos': todos_los_cursos,
        'active_page': 'registrar_alumno',
        'selected_curso': selected_curso if 'selected_curso' in locals() else '',
        'descripcion_adicional': descripcion_adicional if 'descripcion_adicional' in locals() else '',
        'discapacidades_seleccionadas': discapacidades_seleccionadas if 'discapacidades_seleccionadas' in locals() else '',
    }
    return render(request, 'dashboardTutor/registrar_alumno.html', context)


# dashboardTutor/views.py

@login_required
@role_required(allowed_roles=[3])
def editar_alumno_view(request, persona_id):
    print("\n--- INICIANDO VISTA editar_alumno_view ---") # Mensaje de inicio
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 3:
        return redirect('login:login')

    tutor_actual = get_object_or_404(Tutor, persona=request.user)
    alumno_persona = get_object_or_404(PersonaFisica, pk=persona_id)
    if not tutor_actual.estudiante_set.filter(persona=alumno_persona).exists():
        messages.error(request, "No tienes permiso para editar a este alumno.")
        return redirect('dashboard_tutor:alumnos')

    alumno_estudiante = get_object_or_404(Estudiante, persona=alumno_persona)

    if request.method == 'POST':
        print("-> Método es POST. Procesando formulario.") # Mensaje para POST
        form = AlumnoForm(request.POST, instance=alumno_persona)
        
        # Verificamos si el formulario es válido
        if form.is_valid():
            print("-> Formulario es VÁLIDO. Guardando datos...") # Mensaje de éxito de validación
            form.save()
            
            curso_id = request.POST.get('curso')
            if curso_id:
                alumno_estudiante.curso = Curso.objects.get(pk=curso_id)
            else:
                alumno_estudiante.curso = None

            discapacidades_ids_str = request.POST.get('discapacidades_seleccionadas', '')
            print(f"-> IDs de discapacidades recibidas: '{discapacidades_ids_str}'") # Muestra los IDs recibidos

            if discapacidades_ids_str:
                ids_lista = discapacidades_ids_str.split(',')
                alumno_estudiante.discapacidades.set(ids_lista)
                print(f"-> Guardando discapacidades: {ids_lista}") # Muestra los IDs que se guardan
            else:
                alumno_estudiante.discapacidades.clear()
                print("-> No se recibieron discapacidades, limpiando la lista.") # Muestra si se limpia
            
            descripcion_adicional = request.POST.get('descripcion_adicional', '').strip()
            # Validar longitud máxima de descripción adicional
            if len(descripcion_adicional) > 255:
                messages.error(request, 'La descripción adicional no puede tener más de 255 caracteres.')
                context = {
                    'form': form,
                    'alumno': alumno_persona,
                    'estudiante': alumno_estudiante,
                    'tipos_discapacidad': TipoDiscapacidad.objects.all(),
                    'especificas_discapacidad': DiscapacidadEspecifica.objects.all(),
                    'cursos': Curso.objects.all(),
                    'active_page': 'alumnos',
                }
                return render(request, 'dashboardTutor/editar_alumno.html', context)
            alumno_estudiante.descripcion_adicional = descripcion_adicional
            alumno_estudiante.save()

            messages.success(request, 'Los datos del alumno han sido actualizados con éxito.')
            print("-> ¡ÉXITO! Redirigiendo a la lista de alumnos.") # Mensaje final
            return redirect('dashboard_tutor:alumnos')
        else:
            # Si el formulario NO es válido, nos dirá por qué
            print("-> Formulario es INVÁLIDO.")
            print("-> Errores del formulario:", form.errors.as_json()) # ¡ESTE ES EL MENSAJE MÁS IMPORTANTE!
            messages.error(request, 'Hubo un error al guardar. Por favor, revisa los datos.')

    else:
        print("-> Método es GET. Mostrando formulario de edición.") # Mensaje para GET
        form = AlumnoForm(instance=alumno_persona)

    context = {
        'form': form,
        'alumno': alumno_persona,
        'estudiante': alumno_estudiante,
        'tipos_discapacidad': TipoDiscapacidad.objects.all(),
        'especificas_discapacidad': DiscapacidadEspecifica.objects.all(),
        'cursos': Curso.objects.all(),
        'active_page': 'alumnos',
    }
    return render(request, 'dashboardTutor/editar_alumno.html', context)


@login_required
@role_required(allowed_roles=[3])
def eliminar_alumno_view(request, persona_id):
    alumno_persona = get_object_or_404(PersonaFisica, pk=persona_id)

    tutor_actual = get_object_or_404(Tutor, persona=request.user)
    if not tutor_actual.estudiante_set.filter(pk=alumno_persona.pk).exists():
        messages.error(request, "No tienes permiso para modificar a este alumno.")
        return redirect('dashboard_tutor:alumnos')

    if request.method == 'POST':
        alumno_persona.is_active = False
        alumno_persona.save()
        messages.success(request, f"El alumno {alumno_persona.nombre} {alumno_persona.apellido} ha sido dado de baja.")
    
    return redirect('dashboard_tutor:alumnos')

@login_required
@role_required(allowed_roles=[3])
def alumnos_view(request):
    """
    Muestra al tutor una lista de TODOS sus alumnos (activos e inactivos) con paginación, búsqueda y filtros.
    """
    from django.core.paginator import Paginator
    from django.db.models import Q
    
    if not hasattr(request.user, 'id_rol') or request.user.id_rol.pk != 3:
        return redirect('login:login')
    try:
        tutor = Tutor.objects.get(persona=request.user)
        # Obtener todos los alumnos del tutor
        alumnos_del_tutor = tutor.estudiante_set.all().select_related('persona', 'curso')
        
        # Obtener parámetros de búsqueda y filtros
        search_query = request.GET.get('search', '').strip()
        estado_filter = request.GET.get('estado', '')
        curso_filter = request.GET.get('curso', '')
        
        # Aplicar búsqueda (nombre, apellido, DNI)
        if search_query:
            alumnos_del_tutor = alumnos_del_tutor.filter(
                Q(persona__nombre__icontains=search_query) |
                Q(persona__apellido__icontains=search_query) |
                Q(persona__dni__icontains=search_query)
            )
        
        # Aplicar filtro de estado
        if estado_filter == 'activo':
            alumnos_del_tutor = alumnos_del_tutor.filter(persona__is_active=True)
        elif estado_filter == 'inactivo':
            alumnos_del_tutor = alumnos_del_tutor.filter(persona__is_active=False)
        
        # Aplicar filtro de curso
        if curso_filter:
            alumnos_del_tutor = alumnos_del_tutor.filter(curso_id=curso_filter)
        
        # Ordenar resultados
        alumnos_del_tutor = alumnos_del_tutor.order_by('persona__apellido', 'persona__nombre')
        
        # Paginación
        items_per_page = request.GET.get('per_page', '10')
        try:
            items_per_page = int(items_per_page)
            if items_per_page not in [10, 25, 50, 100]:
                items_per_page = 10
        except ValueError:
            items_per_page = 10
        
        paginator = Paginator(alumnos_del_tutor, items_per_page)
        page_number = request.GET.get('page', 1)
        alumnos_page = paginator.get_page(page_number)
        
        # Obtener lista de cursos para el filtro
        cursos_disponibles = Curso.objects.all().order_by('titulo')
        
    except Tutor.DoesNotExist:
        messages.error(request, 'Error: Tu usuario no tiene un perfil de tutor asociado.')
        return redirect('login:home')

    context = {
        'alumnos': alumnos_page,
        'active_page': 'alumnos',
        'search_query': search_query,
        'estado_filter': estado_filter,
        'curso_filter': curso_filter,
        'items_per_page': items_per_page,
        'cursos_disponibles': cursos_disponibles,
        'total_alumnos': paginator.count,
    }
    return render(request, 'dashboardTutor/alumnos.html', context)

@login_required
@role_required(allowed_roles=[3])
def reactivar_alumno_view(request, persona_id):
    """
    Cambia el estado de un alumno inactivo a activo.
    """
    # Verificación de seguridad: Asegurarse de que el tutor tiene permiso sobre el alumno
    tutor_actual = get_object_or_404(Tutor, persona=request.user)
    alumno_persona = get_object_or_404(PersonaFisica, pk=persona_id)

    if not tutor_actual.estudiante_set.filter(pk=alumno_persona.pk).exists():
        messages.error(request, "No tienes permiso para modificar a este alumno.")
        return redirect('dashboard_tutor:alumnos')

    if request.method == 'POST':
        alumno_persona.is_active = True
        alumno_persona.save()
        messages.success(request, f"El alumno {alumno_persona.nombre} {alumno_persona.apellido} ha sido reactivado.")
    
    return redirect('dashboard_tutor:alumnos')