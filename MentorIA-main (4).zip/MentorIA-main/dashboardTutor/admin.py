# dashboardTutor/admin.py
from django.contrib import admin
from .models import Tutor, Estudiante, TipoDiscapacidad, DiscapacidadEspecifica

admin.site.register(Tutor)
admin.site.register(Estudiante)
admin.site.register(TipoDiscapacidad)
admin.site.register(DiscapacidadEspecifica)