# dashboardTutor/forms.py
from django import forms
from django.core.exceptions import ValidationError
from django.core.validators import EmailValidator
from login.models import PersonaFisica
import re

class AlumnoForm(forms.ModelForm):
    class Meta:
        model = PersonaFisica
        fields = ['nombre', 'apellido', 'dni', 'mail', 'numCel']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Verificamos si es un formulario de edición
        if self.instance and self.instance.pk:
            # Usamos 'readonly' para que el DNI se envíe y el formulario sea válido.
            self.fields['dni'].widget.attrs['readonly'] = True
    
    def clean_nombre(self):
        """Valida que el nombre solo contenga letras y espacios simples"""
        nombre = self.cleaned_data.get('nombre')
        
        if nombre:
            # Eliminar espacios al inicio y al final
            nombre = nombre.strip()
            
            # Validar longitud máxima
            if len(nombre) > 50:
                raise ValidationError('El nombre no puede tener más de 50 caracteres.')
            
            # Validar longitud mínima
            if len(nombre) < 2:
                raise ValidationError('El nombre debe tener al menos 2 caracteres.')
            
            # Validar que solo contenga letras, espacios simples y tildes
            if not re.match(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ]+(\s[a-zA-ZáéíóúÁÉÍÓÚñÑ]+)*$', nombre):
                raise ValidationError('El nombre solo puede contener letras y espacios simples (sin números ni caracteres especiales).')
        
        return nombre
    
    def clean_apellido(self):
        """Valida que el apellido solo contenga letras y espacios simples"""
        apellido = self.cleaned_data.get('apellido')
        
        if apellido:
            # Eliminar espacios al inicio y al final
            apellido = apellido.strip()
            
            # Validar longitud máxima
            if len(apellido) > 50:
                raise ValidationError('El apellido no puede tener más de 50 caracteres.')
            
            # Validar longitud mínima
            if len(apellido) < 2:
                raise ValidationError('El apellido debe tener al menos 2 caracteres.')
            
            # Validar que solo contenga letras, espacios simples y tildes
            if not re.match(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ]+(\s[a-zA-ZáéíóúÁÉÍÓÚñÑ]+)*$', apellido):
                raise ValidationError('El apellido solo puede contener letras y espacios simples (sin números ni caracteres especiales).')
        
        return apellido
    
    def clean_dni(self):
        """Valida que el DNI sea un número positivo sin letras ni caracteres especiales"""
        dni = self.cleaned_data.get('dni')
        
        # Verificar que sea un número positivo
        if dni is not None:
            if dni <= 0:
                raise ValidationError('El DNI debe ser un número positivo.')
            
            # Verificar que tenga entre 7 y 8 dígitos
            dni_str = str(dni)
            if len(dni_str) < 7:
                raise ValidationError('El DNI debe tener al menos 7 dígitos.')
            
            if len(dni_str) > 8:
                raise ValidationError('El DNI no puede tener más de 8 dígitos.')
            
            # Si es un nuevo registro (no edición), verificar que el DNI no exista
            if not self.instance.pk:
                if PersonaFisica.objects.filter(dni=dni).exists():
                    raise ValidationError(f'El DNI {dni} ya está registrado. No es posible volver a registrarlo.')
        
        return dni
    
    def clean_mail(self):
        """Valida que el mail tenga un formato válido de correo electrónico"""
        mail = self.cleaned_data.get('mail')
        
        if mail:
            # Eliminar espacios al inicio y al final
            mail = mail.strip()
            
            # Validar longitud máxima
            if len(mail) > 50:
                raise ValidationError('El correo electrónico no puede tener más de 50 caracteres.')
            
            # Validar formato de correo electrónico
            email_validator = EmailValidator(message='Ingrese un correo electrónico válido.')
            try:
                email_validator(mail)
            except ValidationError:
                raise ValidationError('Ingrese un correo electrónico válido (ejemplo: usuario@dominio.com).')
        
        return mail
    
    def clean_numCel(self):
        """Valida que el número de celular solo contenga números"""
        numCel = self.cleaned_data.get('numCel')
        
        if numCel:
            # Eliminar espacios al inicio y al final
            numCel = numCel.strip()
            
            # Validar longitud máxima
            if len(numCel) > 15:
                raise ValidationError('El número de celular no puede tener más de 15 caracteres.')
            
            # Validar longitud mínima
            if len(numCel) < 8:
                raise ValidationError('El número de celular debe tener al menos 8 dígitos.')
            
            # Permitir solo dígitos
            if not re.match(r'^[0-9]+$', numCel):
                raise ValidationError('El número de celular solo puede contener números.')
        
        return numCel