# login/middleware.py

from django.utils.cache import add_never_cache_headers

class CacheControlMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Primero, obtenemos la respuesta de la vista como Django lo haría normalmente.
        response = self.get_response(request)

        # Verificamos si el usuario está autenticado.
        if request.user.is_authenticated:
            # Si está autenticado, le decimos al navegador que NUNCA guarde
            # esta página en la caché.
            add_never_cache_headers(response)
            
        return response