# login/forms.py

from django import forms

class LoginForm(forms.Form):
    # Usamos RegexField para validar que solo sean 8 dígitos numéricos.
    dni = forms.RegexField(
        label='DNI',
        regex=r'^\d{8}$',  # Exige exactamente 8 dígitos (^) al principio y ($) al final.
        error_messages={
            'invalid': 'El DNI debe contener exactamente 8 números.',
            'required': 'Este campo es obligatorio.'
        },
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'id': 'id_dni', # ID que usará el JavaScript
            'name': 'dni',
            'maxlength': '8',
            'required': True,
            'inputmode': 'numeric', # Muestra el teclado numérico en móviles
            'autocomplete': 'username'
        })
    )

    password = forms.CharField(
        label='Contraseña',
        max_length=128, # La validación de máximo 128 caracteres se hace aquí.
        error_messages={'required': 'Este campo es obligatorio.'},
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'id': 'id_password',
            'name': 'password',
            'required': True,
            'maxlength': '128', # También se limita en el HTML
            'autocomplete': 'current-password'
        })
    )