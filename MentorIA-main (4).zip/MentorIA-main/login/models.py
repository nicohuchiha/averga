import hashlib
from django.db import models
# ❗️ PASO 1: Importa el BaseUserManager
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

# ❗️ PASO 2: Crea el Manager Personalizado
# ❗️ PASO 2: Modifica el Manager
class PersonaFisicaManager(BaseUserManager):
    """
    Manager para el modelo PersonaFisica.
    """
    def create_user(self, dni, password=None, **extra_fields):
        if not dni:
            raise ValueError('El DNI es obligatorio')
        user = self.model(dni=dni, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, dni, password=None, **extra_fields):
        # El sistema de Django necesita esta función para crear superusuarios
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(dni, password, **extra_fields)

    def get_by_natural_key(self, dni):
        return self.get(dni=dni)

class Rol(models.Model):
    # Este modelo ahora refleja correctamente tu tabla en la base de datos,
    # que solo tiene un 'id' (la clave primaria o pk) y la descripción.
    descripcionRol = models.CharField(max_length=50, db_column='"descripcionRol"')

    def __str__(self):
        return self.descripcionRol

# ❗️ PASO 3: Modifica la clase PersonaFisica
# Ahora hereda de AbstractBaseUser y PermissionsMixin
class PersonaFisica(AbstractBaseUser, PermissionsMixin):
    id_rol = models.ForeignKey(Rol, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    dni = models.PositiveIntegerField(unique=True)
    mail = models.CharField(max_length=50, null=True, blank=True)
    numCel = models.CharField(null=True, blank=True)
    
    # El campo de contraseña ahora se llama 'password' por convención de AbstractBaseUser
    # PERO, el db_column sigue apuntando a tu columna 'contraseña' original.
    password = models.CharField(max_length=128, db_column='contraseña')
    fechaRegistro = models.DateField(db_column='"fechaRegistro"')
    primer_login = models.BooleanField(default=True)

    # Campos requeridos por Django para el admin
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)

    USERNAME_FIELD = 'dni'
    REQUIRED_FIELDS = ['nombre', 'apellido', 'id_rol']
    
    objects = PersonaFisicaManager()

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

    # ❗️ PASO 4: Añade los métodos de contraseña que Django busca
    def set_password(self, raw_password):
        """
        Hashea la contraseña usando hashlib y la guarda.
        """
        self.password = hashlib.sha256(raw_password.encode()).hexdigest()

    def check_password(self, raw_password):
        """
        Verifica la contraseña de dos maneras:
        1. Si es el primer login, compara el texto plano.
        2. Si no, compara el hash sha256.
        """
        if self.primer_login:
            # Si es el primer inicio de sesión, la contraseña en la BD está en texto plano.
            return raw_password == self.password
        else:
            # Si ya cambió la contraseña, comparamos el hash.
            hashed_input = hashlib.sha256(raw_password.encode()).hexdigest()
            return self.password == hashed_input

   