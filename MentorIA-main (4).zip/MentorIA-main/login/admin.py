# login/admin.py

from django.contrib import admin
from login.models import Rol, PersonaFisica # <-- CORREGIDO

# Register your models here.
admin.site.register(Rol)
admin.site.register(PersonaFisica)