# login/backends.py
# Ya no importamos check_password
from .models import PersonaFisica

class PersonaFisicaBackend:
    def authenticate(self, request, username=None, password=None, **kwargs):
        try:
            # Busca al usuario por DNI
            user = PersonaFisica.objects.get(dni=username)
            
            # --- CAMBIO CLAVE ---
            # Compara el texto de la contraseña directamente
            if user.contraseña == password:
                return user
        except PersonaFisica.DoesNotExist:
            return None
        return None

    def get_user(self, user_id):
        try:
            return PersonaFisica.objects.get(pk=user_id)
        except PersonaFisica.DoesNotExist:
            return None