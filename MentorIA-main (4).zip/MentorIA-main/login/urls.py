from django.urls import path
from . import views

# El app_name es opcional aquí, pero es buena práctica
app_name = 'login'

urlpatterns = [
    # URLs que SÍ pertenecen a esta app
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('cambiar-contrasena/<int:user_id>/', views.cambiar_contrasena_view, name='cambiar_contrasena'),

]
