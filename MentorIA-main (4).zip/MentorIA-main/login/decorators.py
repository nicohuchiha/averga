# login/decorators.py
from django.views.decorators.cache import never_cache

from django.shortcuts import redirect
from django.contrib import messages

# Mapeo de roles a sus dashboards.
DASHBOARD_URLS = {
    1: 'dashboard_admin:index',
    2: 'dashboard_profesor:index',
    3: 'dashboard_tutor:index',
    4: 'dashboard_alumno:index',
}

def role_required(allowed_roles=[]):
    def decorator(view_func):
        def wrapper(request, *args, **kwargs):
            # Si el usuario no está logueado, el decorador @login_required ya lo habrá redirigido
            if not request.user.is_authenticated:
                 return redirect('login:login')

            # Si debe cambiar su contraseña, forzamos redirección antes de cualquier acceso
            if getattr(request.user, 'primer_login', False):
                return redirect('login:cambiar_contrasena', user_id=request.user.id)

            # Verificamos si tiene un rol asignado
            if hasattr(request.user, 'id_rol') and request.user.id_rol:
                user_role = request.user.id_rol.pk
                
                # Si el rol del usuario está en la lista de roles permitidos, le damos acceso
                if user_role in allowed_roles:
                    return view_func(request, *args, **kwargs)
                else:
                    # Si no, lo redirigimos a su propio dashboard
                    messages.error(request, 'No tienes permiso para acceder a esta página.')
                    user_dashboard = DASHBOARD_URLS.get(user_role, 'login:login')
                    return redirect(user_dashboard)
            
            # Si el usuario no tiene rol, lo sacamos por seguridad
            messages.error(request, 'No tienes un rol asignado. Contacta al administrador.')
            return redirect('login:logout')
        return wrapper
    return decorator

def anonymous_required(view_func):
    """
    Decorador que redirige al usuario a su dashboard si ya está autenticado.
    """
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            # Si el usuario debe cambiar su contraseña, lo forzamos a esa vista
            if getattr(request.user, 'primer_login', False):
                return redirect('login:cambiar_contrasena', user_id=request.user.id)

            # Si el usuario ya está logueado, lo mandamos a su dashboard correspondiente.
            user_role = getattr(request.user, 'id_rol', None)
            if user_role:
                user_dashboard = DASHBOARD_URLS.get(user_role.pk, 'login:logout')
                return redirect(user_dashboard)
            else:
                # Si no tiene rol, por seguridad lo deslogueamos.
                return redirect('login:logout')
        
        # Si no está logueado, le mostramos la página que quería (ej. el login).
        return view_func(request, *args, **kwargs)
    return wrapper