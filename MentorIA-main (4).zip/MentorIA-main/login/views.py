from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import LoginForm
from .models import PersonaFisica
from .models import PersonaFisica
from .decorators import anonymous_required, never_cache # 

@anonymous_required # 
def login_view(request):
    # Lógica clave: Si el usuario ya está autenticado, lo redirige inmediatamente.
    if request.user.is_authenticated:
        user = request.user
        if hasattr(user, 'id_rol'):
            if user.id_rol.pk == 1:
                return redirect('dashboard_admin:index')
            elif user.id_rol.pk == 2:
                return redirect('dashboard_profesor:index')
            elif user.id_rol.pk == 3:
                return redirect('dashboard_tutor:index')
            elif user.id_rol.pk == 4:
                return redirect('dashboard_alumno:index')
        logout(request)
        return redirect('login:login')

    # Si el usuario NO está autenticado, procesamos el formulario.
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            dni = form.cleaned_data['dni']
            password = form.cleaned_data['password']
            user = authenticate(request, username=dni, password=password)

            if user is not None:
                login(request, user)
                if user.primer_login:
                    return redirect('login:cambiar_contrasena', user_id=user.id)
                else:
                    if hasattr(user, 'id_rol'):
                        if user.id_rol.pk == 1: return redirect('dashboard_admin:index')
                        elif user.id_rol.pk == 2: return redirect('dashboard_profesor:index')
                        elif user.id_rol.pk == 3: return redirect('dashboard_tutor:index')
                        elif user.id_rol.pk == 4: return redirect('dashboard_alumno:index')
                    logout(request) 
                    messages.error(request, 'No tienes un rol asignado para acceder.')
                    return redirect('login:login')
            else:
                messages.error(request, 'El DNI o la contraseña son incorrectos.')
    else:
        form = LoginForm()

    return render(request, 'login/login.html', {'form': form})

@login_required
@never_cache
def cambiar_contrasena_view(request, user_id):
    if not request.user.is_authenticated or request.user.id != user_id:
        return redirect('login:login')
    try:
        usuario = PersonaFisica.objects.get(pk=user_id)
    except PersonaFisica.DoesNotExist:
        return redirect('login:login')
    if request.method == 'POST':
        nueva_contrasena = request.POST.get('nueva_contrasena')
        confirmar_contrasena = request.POST.get('confirmar_contrasena')

        # Validación de longitud de contraseña.
        if not nueva_contrasena or len(nueva_contrasena) < 8:
            context = {'error': 'La contraseña debe tener al menos 8 caracteres.'}
            return render(request, 'login/cambiar_contrasena.html', context)
        if len(nueva_contrasena) > 64:
            context = {'error': 'La contraseña no puede tener más de 64 caracteres.'}
            return render(request, 'login/cambiar_contrasena.html', context)
        
        # Validación de coincidencia.
        if nueva_contrasena != confirmar_contrasena:
            context = {'error': 'Las contraseñas no coinciden.'}
            return render(request, 'login/cambiar_contrasena.html', context)
        
        # Si todas las validaciones pasan, actualizar la contraseña.
        usuario.set_password(nueva_contrasena)
        usuario.primer_login = False
        usuario.save()
        messages.success(request, '¡Contraseña actualizada correctamente! Por favor, inicia sesión de nuevo.')
        logout(request)
        return redirect('login:login')
    return render(request, 'login/cambiar_contrasena.html')

@login_required
def logout_view(request):
    logout(request)
    messages.success(request, 'Has cerrado sesión exitosamente.')
    return redirect('login:login')
